from core.objective.AbstractObjective import AbstractObjective
from core.objective.BBBObjective import BBBObjective
from core.objective.FQuadObjective import FQuadObjective
from core.objective.FClassicObjective import FClassicObjective
from core.objective.McAllisterObjective import McAllisterObjective
from core.objective.TolstikhinObjective import TolstikhinObjective
